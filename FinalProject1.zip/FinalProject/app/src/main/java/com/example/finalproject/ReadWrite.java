package com.example.finalproject;

import android.content.Context;
import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.InputStreamReader;


public class ReadWrite {
    private void Writer(String data, String FileName, Context context) {
        try {
            FileOutputStream outputStream = context.openFileOutput(FileName,Context.MODE_PRIVATE);
            outputStream.write(data.getBytes());
            outputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    private String Reader(String FileName, Context context){
        String Text = "";
        try{
            BufferedReader reader = new BufferedReader(  new InputStreamReader(context.getAssets().open(FileName)));
            // do reading, usually loop until end of file reading
            String Line;

            while ((Line = reader.readLine()) != null) {
                StringBuilder sb = new StringBuilder(Text);
                sb.append(Line);
            }

        }catch(Exception e){
            e.printStackTrace();
        }
        return Text;


    }


}
